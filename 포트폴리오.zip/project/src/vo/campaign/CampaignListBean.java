package vo.campaign;

public class CampaignListBean {
	private int group_no;
	private int campaign_list_no;
	private String campaign_list_group;
	private String campaign_list_group_intro;
	private String campaign_list_amount;
	
	public int getCampaign_list_no() {
		return campaign_list_no;
	}
	public void setCampaign_list_no(int campaign_list_no) {
		this.campaign_list_no = campaign_list_no;
	}
	public String getCampaign_list_group() {
		return campaign_list_group;
	}
	public void setCampaign_list_group(String campaign_list_group) {
		this.campaign_list_group = campaign_list_group;
	}
	public String getCampaign_list_group_intro() {
		return campaign_list_group_intro;
	}
	public void setCampaign_list_group_intro(String campaign_list_group_intro) {
		this.campaign_list_group_intro = campaign_list_group_intro;
	}
	public String getCampaign_list_amount() {
		return campaign_list_amount;
	}
	public void setCampaign_list_amount(String campaign_list_amount) {
		this.campaign_list_amount = campaign_list_amount;
	}
	public int getGroup_no() {
		return group_no;
	}
	public void setGroup_no(int group_no) {
		this.group_no = group_no;
	}
	
}