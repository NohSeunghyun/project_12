package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class SearchPWService {

	//아이디, 핸드폰번호, 이메일로 비밀번호 찾기 Service
	public String searchPW(String id, String phone, String email) {
		String searchPW = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
	
			searchPW = loginDAO.searchPW(id, phone, email);
		} catch (Exception e) {
			System.out.println("searchPWService 에러" + e);
		} finally {
			close(con);
		}
		return searchPW;
	}

}
