package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.CampaignDAO;
import vo.campaign.CampaignListBean;

public class SupportGroupInsertService {

	//캠페인 지원 단체 추가 Service
	public boolean supportGroupInsert(CampaignListBean supportBean) {
		boolean isSupportGroupInsertSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int insertCount = campaignDAO.supportInsert(supportBean);
			
			if (insertCount > 0) {
				commit(con);
				isSupportGroupInsertSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("supportGroupInsertService 에러" + e);
		} finally {
			close(con);
		}
		return isSupportGroupInsertSuccess;
	}

	//단체회원 캠페인 지원단체 신청 Service
	public boolean supportGroupApplicationInsert(CampaignListBean supportBean) {
		boolean isSupportGroupInsertSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			int insertCount = campaignDAO.supportGroupApplicationInsert(supportBean);
			
			if (insertCount > 0) {
				commit(con);
				isSupportGroupInsertSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("supportGroupApplicationInsertService 에러" + e);
		} finally {
			close(con);
		}
		return isSupportGroupInsertSuccess;
	}

}
