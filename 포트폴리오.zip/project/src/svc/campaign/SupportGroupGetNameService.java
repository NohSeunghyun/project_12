package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.CampaignDAO;

public class SupportGroupGetNameService {

	//단체회원 지원단체 신청 전 단체이름 가져오기 Service
	public String getGroupName(String id) {
		String group_name = "";
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			group_name = campaignDAO.getSupportGroupName(id);
		} catch (Exception e) {
			System.out.println("getGroupNameService 에러" + e);
		} finally {
			close(con);
		}
		return group_name;
	}

	//단체회원 지원단체 신청 전 회원등급 가져오기 Service
	public String getGroupGrade(String id) {
		String group_grade = "";
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			group_grade = campaignDAO.getSupportGroupGrade(id);
		} catch (Exception e) {
			System.out.println("getGroupGradeService 에러" + e);
		} finally {
			close(con);
		}
		return group_grade;
	}

}
