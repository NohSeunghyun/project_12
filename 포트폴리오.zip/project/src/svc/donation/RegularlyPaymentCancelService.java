package svc.donation;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.DonationDAO;

public class RegularlyPaymentCancelService {

	//일반회원 카드 정기결제 취소 Service
	public boolean normalMemberCardRegularlyPaymentCancel(int donation_no) {
		boolean cancelSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			updateCount = donationDAO.normalMemberCardRegularlyPaymentCancel(donation_no);
			
			if (updateCount > 0) {
				commit(con);
				cancelSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("normalMemberCardRegularlyPaymentCancelService 에러" + e);
		} finally {
			close(con);
		}
		return cancelSuccess;
	}

	//일반회원 계좌 정기결제 취소 Service
	public boolean normalMemberBankRegularlyPaymentCancel(int donation_no) {
		boolean cancelSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			updateCount = donationDAO.normalMemberBankRegularlyPaymentCancel(donation_no);
			
			if (updateCount > 0) {
				commit(con);
				cancelSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("normalMemberBankRegularlyPaymentCancelService 에러" + e);
		} finally {
			close(con);
		}
		return cancelSuccess;
	}

	//기업/단체회원 카드 정기결제 취소 Service
	public boolean comgrpMemberCardRegularlyPaymentCancel(int donation_no) {
		boolean cancelSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			updateCount = donationDAO.comgrpMemberCardRegularlyPaymentCancel(donation_no);
			
			if (updateCount > 0) {
				commit(con);
				cancelSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("comgrpMemberCardRegularlyPaymentCancelService 에러" + e);
		} finally {
			close(con);
		}
		return cancelSuccess;
	}

	//기업/단체회원 계좌 정기결제 취소 Service
	public boolean comgrpMemberBankRegularlyPaymentCancel(int donation_no) {
		boolean cancelSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			updateCount = donationDAO.comgrpMemberBankRegularlyPaymentCancel(donation_no);
			
			if (updateCount > 0) {
				commit(con);
				cancelSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("comgrpMemberBankRegularlyPaymentCancelService 에러" + e);
		} finally {
			close(con);
		}
		return cancelSuccess;
	}

}
