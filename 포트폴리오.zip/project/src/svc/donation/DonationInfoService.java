package svc.donation;

import static db.JdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;

import dao.DonationDAO;
import vo.donation.DonationBankBean;
import vo.donation.DonationBean;
import vo.donation.DonationCardBean;

public class DonationInfoService {

	//일반회원 기부번호 가져오기 Service
	public int getNormalMemberDonationNo() {
		int donation_no = 0;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			donation_no = donationDAO.getNormalMemberDonationNo();
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationNoService 에러" + e);
		} finally {
			close(con);
		}
		return donation_no;
	}
	
	//기업/단체회원 기부번호 가져오기 Service
	public int getComgrpMemberDonationNo() {
		int donation_no = 0;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			donation_no = donationDAO.getComgrpMemberDonationNo();
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationNoService 에러" + e);
		} finally {
			close(con);
		}
		return donation_no;
	}

	//일반회원 기부내역 가져오기 Service
	public ArrayList<DonationBean> getNormalMemberDonationInfo() {
		ArrayList<DonationBean> normalDonationInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			normalDonationInfo = donationDAO.getNormalMemberDonationInfo();
		} catch (Exception e) {
			System.out.println("getNormalMemberDonationInfoService 에러" + e);
		} finally {
			close(con);
		}
		return normalDonationInfo;
	}

	//기업/단체회원 기부내역 가져오기 Service
	public ArrayList<DonationBean> getComgrpMemberDonationInfo() {
		ArrayList<DonationBean> comgrpDonationInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			comgrpDonationInfo = donationDAO.getComgrpMemberDonationInfo();
		} catch (Exception e) {
			System.out.println("getComgrpMemberDonationInfoService 에러" + e);
		} finally {
			close(con);
		}
		return comgrpDonationInfo;
	}

	//관리자 단체회원 지원단체 신청 승인 전 신청단체 가져오기 Service
	public ArrayList<DonationBean> getSupportGroupApplicationList() {
		ArrayList<DonationBean> supportGroupApplicationList = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			supportGroupApplicationList = donationDAO.getSupportGroupApplicationList();
		} catch (Exception e) {
			System.out.println("getSupportGroupApplicationListService 에러" + e);
		} finally {
			close(con);
		}
		return supportGroupApplicationList;
	}

	//관리자 정기결제 조회 전 일반회원 정기결제 기부내역 가져오기 Service
	public ArrayList<DonationBean> getAdminNormalMemberRegularlyDonationInfo() {
		ArrayList<DonationBean> normalDonationInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			normalDonationInfo = donationDAO.getAdminNormalMemberRegularlyDonationInfo();
		} catch (Exception e) {
			System.out.println("getAdminNormalMemberRegularlyDonationInfoService 에러" + e);
		} finally {
			close(con);
		}
		return normalDonationInfo;
	}

	//관리자 정기결제 조회 전 기업/단체회원 정기결제 기부내역 가져오기 Service
	public ArrayList<DonationBean> getAdminComgrpMemberRegularlyDonationInfo() {
		ArrayList<DonationBean> comgrpDonationInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			comgrpDonationInfo = donationDAO.getAdminComgrpMemberRegularlyDonationInfo();
		} catch (Exception e) {
			System.out.println("getAdminComgrpMemberRegularlyDonationInfoService 에러" + e);
		} finally {
			close(con);
		}
		return comgrpDonationInfo;
	}

	//관리자 정기결제 조회 전 일반회원 카드 정기결제 정보 가져오기 Service
	public ArrayList<DonationCardBean> getAdminNormalMemberRegularlyDonationCardInfo() {
		ArrayList<DonationCardBean> normalDonationCardInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			normalDonationCardInfo = donationDAO.getAdminNormalMemberRegularlyDonationCardInfo();
		} catch (Exception e) {
			System.out.println("getAdminNormalMemberRegularlyDonationCardInfoService 에러" + e);
		} finally {
			close(con);
		}
		return normalDonationCardInfo;
	}

	//관리자 정기결제 조회 전 기업/단체회원 카드 정기결제 정보 가져오기 Service
	public ArrayList<DonationCardBean> getAdminComgrpMemberRegularlyDonationCardInfo() {
		ArrayList<DonationCardBean> comgrpDonationCardInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			comgrpDonationCardInfo = donationDAO.getAdminComgrpMemberRegularlyDonationCardInfo();
		} catch (Exception e) {
			System.out.println("getAdminComgrpMemberRegularlyDonationCardInfoService 에러" + e);
		} finally {
			close(con);
		}
		return comgrpDonationCardInfo;
	}

	//관리자 정기결제 조회 전 일반회원 계좌 정기결제 정보 가져오기 Service
	public ArrayList<DonationBankBean> getAdminNormalMemberRegularlyDonationBankInfo() {
		ArrayList<DonationBankBean> normalDonationBankInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			normalDonationBankInfo = donationDAO.getAdminNormalMemberRegularlyDonationBankInfo();
		} catch (Exception e) {
			System.out.println("getAdminNormalMemberRegularlyDonationBankInfoService 에러" + e);
		} finally {
			close(con);
		}
		return normalDonationBankInfo;
	}

	//관리자 정기결제 조회 전 기업/단체회원 계좌 정기결제 정보 가져오기 Service
	public ArrayList<DonationBankBean> getAdminComgrpMemberRegularlyDonationBankInfo() {
		ArrayList<DonationBankBean> comgrpDonationBankInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			comgrpDonationBankInfo = donationDAO.getAdminComgrpMemberRegularlyDonationBankInfo();
		} catch (Exception e) {
			System.out.println("getAdminComgrpMemberRegularlyDonationBankInfoService 에러" + e);
		} finally {
			close(con);
		}
		return comgrpDonationBankInfo;
	}

}
