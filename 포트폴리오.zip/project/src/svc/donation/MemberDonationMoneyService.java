package svc.donation;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.DonationDAO;

public class MemberDonationMoneyService {

	//일반회원 계좌결제 승인 전 해당 후원금 가져오기 Service
	public long getNormalMemberDonationMoney(int donation_no, String member_id) {
		long donation_money = 0;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			donation_money = donationDAO.getNormalMemberDonationMoney(donation_no, member_id);
		} catch (Exception e) {
			System.out.println("getNormalMemberBankDonationMoneyService 에러" + e);
		} finally {
			close(con);
		}
		return donation_money;
	}
	
	//기업/단체회원 계좌결제 승인 전 해당 후원금 가져오기 Service
	public long getComgrpMemberDonationMoney(int donation_no, String member_id) {
		long donation_money = 0;
		Connection con = null;
		try {
			con = getConnection();
			DonationDAO donationDAO = DonationDAO.getInstance();
			donationDAO.setConnection(con);
			
			donation_money = donationDAO.getComgrpMemberDonationMoney(donation_no, member_id);
		} catch (Exception e) {
			System.out.println("getComgrpMemberBankDonationMoneyService 에러" + e);
		} finally {
			close(con);
		}
		return donation_money;
	}

}
