package action.campaign;

import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.campaign.CampaignInformationService;
import svc.campaign.GrantSendService;
import svc.donation.GetGrantSendHistoryService;
import vo.ActionForward;
import vo.campaign.CampaignHistoryBean;
import vo.campaign.CampaignListBean;

public class SupportGroupIntroProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		String admin_id = (String)session.getAttribute("id");
		
		int group_no = Integer.parseInt(request.getParameter("group_no"));
		
		CampaignInformationService supportGroupInfoService = new CampaignInformationService();
		CampaignListBean supportGroupInfo = supportGroupInfoService.getCampaignDetailInfo(group_no);
		
		if (supportGroupInfo == null) {
			out.println("<script>");
			out.println("alert('정보조회에 실패하였습니다.');");
			out.println("history.back();");
			out.println("</script>");
		} else {
			request.setAttribute("supportGroupInfo", supportGroupInfo);
			if (admin_id == null) {
				forward = new ActionForward("supportGroupIntro.page", false);
			} else {
				AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
				String admin_grade = adminGradeChkService.isAdminGrade(admin_id);
				if (admin_grade != "") {
					String group_name = supportGroupInfo.getCampaign_list_group();
					int campaign_no = supportGroupInfo.getCampaign_list_no();
					GrantSendService grantSendService = new GrantSendService();
					String campaign_name = grantSendService.getCampaignName(campaign_no); 
					
					GetGrantSendHistoryService getGrantSendHistoryService = new GetGrantSendHistoryService();
					ArrayList<CampaignHistoryBean> grantSendHistoryList = getGrantSendHistoryService.getGrantSendHistory(group_name, campaign_name);
					
					request.setAttribute("grantSendHistoryList", grantSendHistoryList);
					forward = new ActionForward("adminSupportGroupIntro.page", false);
				} else {
					forward = new ActionForward("memberSupportGroupIntro.page", false);
				}
			}
		}
		return forward;
	}

}
