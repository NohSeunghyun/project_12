package action.campaign;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.campaign.SupportUpdateService;
import vo.ActionForward;

public class SupportUpdateProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		String group_name = request.getParameter("group_name");
		String group_intro = request.getParameter("group_intro");
		int group_no = Integer.parseInt(request.getParameter("group_no"));
		
		SupportUpdateService supportUpdateService = new SupportUpdateService();
		boolean isSupportUpdateSuccess = supportUpdateService.supportUpdate(group_no, group_name, group_intro);
		
		if (!isSupportUpdateSuccess) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('지원단체 수정에 실패하였습니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			forward = new ActionForward("supportUpdateSuccess.page", false);
		}
		return forward;
	}

}
