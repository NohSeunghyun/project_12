package action.login;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.login.SearchPWService;
import vo.ActionForward;

public class SearchPWProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		String id = request.getParameter("id");
		String phone = request.getParameter("phone1")+"-"+request.getParameter("phone2")+"-"+request.getParameter("phone3");
		String email = request.getParameter("email1")+"@"+request.getParameter("email2");
		
		SearchPWService searchPWService = new SearchPWService();
		String searchPW = searchPWService.searchPW(id, phone, email);
		
		if (searchPW == "") {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('검색 결과가 없습니다.\\n아이디, 휴대폰번호, 이메일을 다시 확인해 주세요.');");
			out.println("history.back();");
			out.println("</script>");
		} else {
		request.setAttribute("searchPW", searchPW);
		request.setAttribute("searchID", id);
		
		forward = new ActionForward("/login/searchPW.jsp", false);
		}
		return forward;
	}

}
