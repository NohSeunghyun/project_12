package action.login;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.login.DeleteMemberChkService;
import svc.login.DeleteMemberService;
import vo.ActionForward;

public class DeleteMemberProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("member_id");
		
		DeleteMemberChkService deleteMemberChkService = new DeleteMemberChkService();
		String category = deleteMemberChkService.isDeleteMemberCategory(id);
		
		if (category == "normal") {
			DeleteMemberService deleteMemberService = new DeleteMemberService();
			boolean isNormalMemberDeleteSuccess = deleteMemberService.isNormalMemberDelete(id);
			if (!isNormalMemberDeleteSuccess) {
				out.println("<script>");
				out.println("alert('회원탈퇴에 실패하였습니다.');");
				out.println("history.back();");
				out.println("</script>");
			} else {
				forward = new ActionForward("deleteSuccess.page", false);
			}
		} else if (category == "comgrp") {
			DeleteMemberService deleteMemberService = new DeleteMemberService();
			boolean isComgrpMemberDeleteSuccess = deleteMemberService.isComgrpMemberDelete(id);
			if (!isComgrpMemberDeleteSuccess) {
				out.println("<script>");
				out.println("alert('회원탈퇴에 실패하였습니다.');");
				out.println("history.back();");
				out.println("</script>");
			} else {
				forward = new ActionForward("deleteSuccess.page", false);
			}
		}
		return forward;
	}

}
