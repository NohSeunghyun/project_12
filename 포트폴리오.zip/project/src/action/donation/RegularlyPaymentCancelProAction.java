package action.donation;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.donation.RegularlyPaymentCancelService;
import svc.login.DeleteMemberChkService;
import vo.ActionForward;

public class RegularlyPaymentCancelProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		int donation_no = Integer.parseInt(request.getParameter("donation_no"));
		String id = request.getParameter("member_id");
		String pay_type = request.getParameter("pay_type");
		
		DeleteMemberChkService deleteMemberChkService = new DeleteMemberChkService();
		String category = deleteMemberChkService.isDeleteMemberCategory(id);
		
		RegularlyPaymentCancelService regularlyPaymentCancelService = new RegularlyPaymentCancelService();
		if (category.equalsIgnoreCase("normal")) {
			if (pay_type.equalsIgnoreCase("C")) {
				boolean cancelSuccess = regularlyPaymentCancelService.normalMemberCardRegularlyPaymentCancel(donation_no);
				
				if (!cancelSuccess) {
					out.println("<script>");
					out.println("alert('정기결제 취소 실패하였습니다.');");
					out.println("window.opener='Self';");
					out.println("window.open('','_parent','');");
					out.println("window.close();");
					out.println("</script>");
				} else {
					forward = new ActionForward("regularlyPaymentCancelSuccess.page", false);
				}
			} else if (pay_type.equalsIgnoreCase("B")) {
				boolean cancelSuccess = regularlyPaymentCancelService.normalMemberBankRegularlyPaymentCancel(donation_no);
				
				if (!cancelSuccess) {
					out.println("<script>");
					out.println("alert('정기결제 취소 실패하였습니다.');");
					out.println("window.opener='Self';");
					out.println("window.open('','_parent','');");
					out.println("window.close();");
					out.println("</script>");
				} else {
					forward = new ActionForward("regularlyPaymentCancelSuccess.page", false);
				}
			}
		} else if (category.equalsIgnoreCase("comgrp")) {
			if (pay_type.equalsIgnoreCase("C")) {
				boolean cancelSuccess = regularlyPaymentCancelService.comgrpMemberCardRegularlyPaymentCancel(donation_no);
				
				if (!cancelSuccess) {
					out.println("<script>");
					out.println("alert('정기결제 취소 실패하였습니다.');");
					out.println("window.opener='Self';");
					out.println("window.open('','_parent','');");
					out.println("window.close();");
					out.println("</script>");
				} else {
					forward = new ActionForward("regularlyPaymentCancelSuccess.page", false);
				}
			} else if (pay_type.equalsIgnoreCase("B")) {
				boolean cancelSuccess = regularlyPaymentCancelService.comgrpMemberBankRegularlyPaymentCancel(donation_no);
				
				if (!cancelSuccess) {
					out.println("<script>");
					out.println("alert('정기결제 취소 실패하였습니다.');");
					out.println("window.opener='Self';");
					out.println("window.open('','_parent','');");
					out.println("window.close();");
					out.println("</script>");
				} else {
					forward = new ActionForward("regularlyPaymentCancelSuccess.page", false);
				}
			}
		}
		return forward;
	}

}
