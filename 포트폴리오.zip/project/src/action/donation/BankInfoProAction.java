package action.donation;

import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.campaign.CampaignListService;
import svc.donation.DonationBankInfoService;
import svc.donation.DonationHistoryService;
import vo.ActionForward;
import vo.campaign.CampaignBean;
import vo.donation.DonationBankBean;
import vo.donation.DonationBean;

public class BankInfoProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		
		AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
		String admin_grade = adminGradeChkService.isAdminGrade(id);
		
		if (!admin_grade.equalsIgnoreCase("A")) {
			out.println("<script>");
			out.println("alert('결제 승인할 권한이 없습니다.\\nA등급만 결제 승인 가능합니다.');");
			out.println("history.back();");
			out.println("</script>");
		} else {
			CampaignListService campaignListService = new CampaignListService();
			ArrayList<CampaignBean> campaignList = campaignListService.getCampaign();
			
			DonationHistoryService donationHistoryService = new DonationHistoryService();
			ArrayList<DonationBean> normalMemberDonationHistory = donationHistoryService.normalMemberDonationHistory();
			ArrayList<DonationBean> comgrpMemberDonationHistory = donationHistoryService.comgrpMemberDonationHistory();
			
			DonationBankInfoService bankPaymentInfoService = new DonationBankInfoService();
			ArrayList<DonationBankBean> normalMemberBankInfo = bankPaymentInfoService.getNormalMemberDonationBankInfo();
			ArrayList<DonationBankBean> comgrpMemberBankInfo = bankPaymentInfoService.getComgrpMemberDonationBankInfo();
			
			request.setAttribute("campaignList", campaignList);
			request.setAttribute("normalMemberDonationHistory", normalMemberDonationHistory);
			request.setAttribute("comgrpMemberDonationHistory", comgrpMemberDonationHistory);
			request.setAttribute("normalMemberBankInfo", normalMemberBankInfo);
			request.setAttribute("comgrpMemberBankInfo", comgrpMemberBankInfo);
			
			forward = new ActionForward("bankPayMentApproveForm.page", false);
		}
		return forward;
	}

}
