package action.donation;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.campaign.CampaignListService;
import svc.donation.DonationInfoService;
import vo.ActionForward;
import vo.campaign.CampaignBean;
import vo.donation.DonationBankBean;
import vo.donation.DonationBean;
import vo.donation.DonationCardBean;

public class AdminRegularlyInfoProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		CampaignListService campaignListService = new CampaignListService();
		ArrayList<CampaignBean> campaignList = campaignListService.getCampaign();
		
		request.setAttribute("campaignList", campaignList);
		
		DonationInfoService donationInfoService = new DonationInfoService();
		
		ArrayList<DonationBean> normalDonationInfo = donationInfoService.getAdminNormalMemberRegularlyDonationInfo();
		ArrayList<DonationBean> comgrpDonationInfo = donationInfoService.getAdminComgrpMemberRegularlyDonationInfo();
		
		request.setAttribute("normalDonationInfo", normalDonationInfo);
		request.setAttribute("comgrpDonationInfo", comgrpDonationInfo);
		
		ArrayList<DonationCardBean> normalDonationCardInfo = donationInfoService.getAdminNormalMemberRegularlyDonationCardInfo();
		ArrayList<DonationCardBean> comgrpDonationCardInfo = donationInfoService.getAdminComgrpMemberRegularlyDonationCardInfo();
		
		request.setAttribute("normalDonationCardInfo", normalDonationCardInfo);
		request.setAttribute("comgrpDonationCardInfo", comgrpDonationCardInfo);
		
		ArrayList<DonationBankBean> normalDonationBankInfo = donationInfoService.getAdminNormalMemberRegularlyDonationBankInfo();
		ArrayList<DonationBankBean> comgrpDonationBankInfo = donationInfoService.getAdminComgrpMemberRegularlyDonationBankInfo();
		
		request.setAttribute("normalDonationBankInfo", normalDonationBankInfo);
		request.setAttribute("comgrpDonationBankInfo", comgrpDonationBankInfo);
		
		forward = new ActionForward("allMemberRegularlyPayMentInfoForm.page", false);
		
		return forward;
	}

}
