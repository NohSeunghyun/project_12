package action.donation;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.campaign.CampaignUpdateService;
import svc.donation.DonationService;
import svc.donation.MemberDonationMoneyService;
import svc.donation.MemberGradeUpdateService;
import svc.donation.MyInfoService;
import svc.login.DeleteMemberChkService;
import vo.ActionForward;
import vo.donation.DonationBean;

public class RegularlyPaymentApproveProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		DonationBean donationInfo = new DonationBean();
		
		int campaign_no = Integer.parseInt(request.getParameter("campaign_no"));
		String member_id = request.getParameter("member_id");
		int donation_no = Integer.parseInt(request.getParameter("donation_no"));
		String pay_type = request.getParameter("pay_type");
		int pay_date1 = Integer.parseInt(request.getParameter("pay_date"));
		int now_date = Integer.parseInt(request.getParameter("now_date"));
		String donation_type = "T";
		
		DeleteMemberChkService memberChkService = new DeleteMemberChkService();
		String member_category = memberChkService.isDeleteMemberCategory(member_id);
		
		String donation_money = "";
		long donation_money1 = 0;
		
		donationInfo.setDonation_campaign_no(campaign_no);
		donationInfo.setDonation_member_id(member_id);
		donationInfo.setDonation_type(donation_type);
		donationInfo.setPay_type(pay_type);
		
		String updateGrade = "";
		
		MemberDonationMoneyService memberDonationMoneyService = new MemberDonationMoneyService();
		DonationService donationService = new DonationService();
		if (pay_date1 != now_date) {
			out.println("<script>");
			out.println("alert('결제하실 수 없습니다.\\n해당 결제일에 결제를 진행해 주세요.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			if (pay_type.equalsIgnoreCase("C")) {
				if (member_category.equalsIgnoreCase("normal")) {
					donation_money = Long.toString(memberDonationMoneyService.getNormalMemberDonationMoney(donation_no, member_id));
					donation_money1 = memberDonationMoneyService.getNormalMemberDonationMoney(donation_no, member_id);
					donationInfo.setDonation_money(donation_money);
					
					boolean donationSuccess = false;
					
					donationSuccess = donationService.donationCardNormalMember(donationInfo);
					
					if (!donationSuccess) {
						out.println("<script>");
						out.println("alert('기부에 실패하였습니다.');");
						out.println("window.opener='Self';");
						out.println("window.open('','_parent','');");
						out.println("window.close();");
						out.println("</script>");
					} else {
						CampaignUpdateService campaignUpdateService = new CampaignUpdateService();
						boolean campaignUpdateSuccess = campaignUpdateService.campaignUpdateAllFundRaised(campaign_no, donation_money1);
						
						if (!campaignUpdateSuccess) {
							out.println("<script>");
							out.println("alert('후원금에 기부 실패하였습니다.');");
							out.println("window.opener='Self';");
							out.println("window.open('','_parent','');");
							out.println("window.close();");
							out.println("</script>");
						} else {
							MyInfoService myInfoService = new MyInfoService();
							int allDonationMoney = myInfoService.getAllDonationMoney(member_id, member_category);
							String grade = myInfoService.getGrade(member_id, member_category);
							
							if ((grade.equalsIgnoreCase("A-") && allDonationMoney >= 100000000) || (grade.equalsIgnoreCase("B") && allDonationMoney >= 100000000) || (grade.equalsIgnoreCase("C") && allDonationMoney >= 100000000)) {
								MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
								boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeAUpdate(member_id, member_category);
								
								if (!memberGradeUpdateSuccess) {
									out.println("<script>");
									out.println("alert('등급 업데이트에 실패하였습니다.');");
									out.println("window.opener='Self';");
									out.println("window.open('','_parent','');");
									out.println("window.close();");
									out.println("</script>");
								} else {
									updateGrade = "A";
								}
							}  else if ((grade.equalsIgnoreCase("B") && allDonationMoney >= 10000000) || (grade.equalsIgnoreCase("C") && allDonationMoney >= 10000000)) {
								MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
								boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeAMinusUpdate(member_id, member_category);
								
								if (!memberGradeUpdateSuccess) {
									out.println("<script>");
									out.println("alert('등급 업데이트에 실패하였습니다.');");
									out.println("window.opener='Self';");
									out.println("window.open('','_parent','');");
									out.println("window.close();");
									out.println("</script>");
								} else {
									updateGrade = "A-";
								}
							} else if (grade.equalsIgnoreCase("C") && allDonationMoney >= 1000000) {
								MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
								boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeBUpdate(member_id, member_category);
								
								if (!memberGradeUpdateSuccess) {
									out.println("<script>");
									out.println("alert('등급 업데이트에 실패하였습니다.');");
									out.println("window.opener='Self';");
									out.println("window.open('','_parent','');");
									out.println("window.close();");
									out.println("</script>");
								} else {
									updateGrade = "B";
								}
							}
						}
					}
				} else if (member_category.equalsIgnoreCase("comgrp")) {
					donation_money = Long.toString(memberDonationMoneyService.getComgrpMemberDonationMoney(donation_no, member_id));
					donation_money1 = memberDonationMoneyService.getComgrpMemberDonationMoney(donation_no, member_id);
					donationInfo.setDonation_money(donation_money);
					
					boolean donationSuccess = false;
					
					donationSuccess = donationService.donationCardComgrpMember(donationInfo);
					
					if (!donationSuccess) {
						out.println("<script>");
						out.println("alert('기부에 실패하였습니다.');");
						out.println("window.opener='Self';");
						out.println("window.open('','_parent','');");
						out.println("window.close();");
						out.println("</script>");
					} else {
						CampaignUpdateService campaignUpdateService = new CampaignUpdateService();
						boolean campaignUpdateSuccess = campaignUpdateService.campaignUpdateAllFundRaised(campaign_no, donation_money1);
						
						if (!campaignUpdateSuccess) {
							out.println("<script>");
							out.println("alert('후원금에 기부 실패하였습니다.');");
							out.println("window.opener='Self';");
							out.println("window.open('','_parent','');");
							out.println("window.close();");
							out.println("</script>");
						} else {
							MyInfoService myInfoService = new MyInfoService();
							int allDonationMoney = myInfoService.getAllDonationMoney(member_id, member_category);
							String grade = myInfoService.getGrade(member_id, member_category);
							
							if ((grade.equalsIgnoreCase("A-") && allDonationMoney >= 100000000) || (grade.equalsIgnoreCase("B") && allDonationMoney >= 100000000) || (grade.equalsIgnoreCase("C") && allDonationMoney >= 100000000)) {
								MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
								boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeAUpdate(member_id, member_category);
								
								if (!memberGradeUpdateSuccess) {
									out.println("<script>");
									out.println("alert('등급 업데이트에 실패하였습니다.');");
									out.println("window.opener='Self';");
									out.println("window.open('','_parent','');");
									out.println("window.close();");
									out.println("</script>");
								} else {
									updateGrade = "A";
								}
							}  else if ((grade.equalsIgnoreCase("B") && allDonationMoney >= 10000000) || (grade.equalsIgnoreCase("C") && allDonationMoney >= 10000000)) {
								MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
								boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeAMinusUpdate(member_id, member_category);
								
								if (!memberGradeUpdateSuccess) {
									out.println("<script>");
									out.println("alert('등급 업데이트에 실패하였습니다.');");
									out.println("window.opener='Self';");
									out.println("window.open('','_parent','');");
									out.println("window.close();");
									out.println("</script>");
								} else {
									updateGrade = "A-";
								}
							} else if (grade.equalsIgnoreCase("C") && allDonationMoney >= 1000000) {
								MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
								boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeBUpdate(member_id, member_category);
								
								if (!memberGradeUpdateSuccess) {
									out.println("<script>");
									out.println("alert('등급 업데이트에 실패하였습니다.');");
									out.println("window.opener='Self';");
									out.println("window.open('','_parent','');");
									out.println("window.close();");
									out.println("</script>");
								} else {
									updateGrade = "B";
								}
							}
						}
					}
				}
			} else if (pay_type.equalsIgnoreCase("B")) {
				if (member_category.equalsIgnoreCase("normal")) {
					donation_money = Long.toString(memberDonationMoneyService.getNormalMemberDonationMoney(donation_no, member_id));
					donation_money1 = memberDonationMoneyService.getNormalMemberDonationMoney(donation_no, member_id);
					donationInfo.setDonation_money(donation_money);
					
					boolean donationSuccess = false;
					
					donationSuccess = donationService.regularlyDonationBankNormalMember(donationInfo);
					
					if (!donationSuccess) {
						out.println("<script>");
						out.println("alert('기부에 실패하였습니다.');");
						out.println("window.opener='Self';");
						out.println("window.open('','_parent','');");
						out.println("window.close();");
						out.println("</script>");
					} else {
						CampaignUpdateService campaignUpdateService = new CampaignUpdateService();
						boolean campaignUpdateSuccess = campaignUpdateService.campaignUpdateAllFundRaised(campaign_no, donation_money1);
						
						if (!campaignUpdateSuccess) {
							out.println("<script>");
							out.println("alert('후원금에 기부 실패하였습니다.');");
							out.println("window.opener='Self';");
							out.println("window.open('','_parent','');");
							out.println("window.close();");
							out.println("</script>");
						} else {
							MyInfoService myInfoService = new MyInfoService();
							int allDonationMoney = myInfoService.getAllDonationMoney(member_id, member_category);
							String grade = myInfoService.getGrade(member_id, member_category);
							
							if ((grade.equalsIgnoreCase("A-") && allDonationMoney >= 100000000) || (grade.equalsIgnoreCase("B") && allDonationMoney >= 100000000) || (grade.equalsIgnoreCase("C") && allDonationMoney >= 100000000)) {
								MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
								boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeAUpdate(member_id, member_category);
								
								if (!memberGradeUpdateSuccess) {
									out.println("<script>");
									out.println("alert('등급 업데이트에 실패하였습니다.');");
									out.println("window.opener='Self';");
									out.println("window.open('','_parent','');");
									out.println("window.close();");
									out.println("</script>");
								} else {
									updateGrade = "A";
								}
							}  else if ((grade.equalsIgnoreCase("B") && allDonationMoney >= 10000000) || (grade.equalsIgnoreCase("C") && allDonationMoney >= 10000000)) {
								MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
								boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeAMinusUpdate(member_id, member_category);
								
								if (!memberGradeUpdateSuccess) {
									out.println("<script>");
									out.println("alert('등급 업데이트에 실패하였습니다.');");
									out.println("window.opener='Self';");
									out.println("window.open('','_parent','');");
									out.println("window.close();");
									out.println("</script>");
								} else {
									updateGrade = "A-";
								}
							} else if (grade.equalsIgnoreCase("C") && allDonationMoney >= 1000000) {
								MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
								boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeBUpdate(member_id, member_category);
								
								if (!memberGradeUpdateSuccess) {
									out.println("<script>");
									out.println("alert('등급 업데이트에 실패하였습니다.');");
									out.println("window.opener='Self';");
									out.println("window.open('','_parent','');");
									out.println("window.close();");
									out.println("</script>");
								} else {
									updateGrade = "B";
								}
							}
						}
					}
				} else if (member_category.equalsIgnoreCase("comgrp")) {
					donation_money = Long.toString(memberDonationMoneyService.getComgrpMemberDonationMoney(donation_no, member_id));
					donation_money1 = memberDonationMoneyService.getComgrpMemberDonationMoney(donation_no, member_id);
					donationInfo.setDonation_money(donation_money);
					
					boolean donationSuccess = false;
					
					donationSuccess = donationService.regularlyDonationBankComgrpMember(donationInfo);
					
					if (!donationSuccess) {
						out.println("<script>");
						out.println("alert('기부에 실패하였습니다.');");
						out.println("window.opener='Self';");
						out.println("window.open('','_parent','');");
						out.println("window.close();");
						out.println("</script>");
					} else {
						MyInfoService myInfoService = new MyInfoService();
						int allDonationMoney = myInfoService.getAllDonationMoney(member_id, member_category);
						String grade = myInfoService.getGrade(member_id, member_category);
						
						if ((grade.equalsIgnoreCase("A-") && allDonationMoney >= 100000000) || (grade.equalsIgnoreCase("B") && allDonationMoney >= 100000000) || (grade.equalsIgnoreCase("C") && allDonationMoney >= 100000000)) {
							MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
							boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeAUpdate(member_id, member_category);
							
							if (!memberGradeUpdateSuccess) {
								out.println("<script>");
								out.println("alert('등급 업데이트에 실패하였습니다.');");
								out.println("window.opener='Self';");
								out.println("window.open('','_parent','');");
								out.println("window.close();");
								out.println("</script>");
							} else {
								updateGrade = "A";
							}
						}  else if ((grade.equalsIgnoreCase("B") && allDonationMoney >= 10000000) || (grade.equalsIgnoreCase("C") && allDonationMoney >= 10000000)) {
							MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
							boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeAMinusUpdate(member_id, member_category);
							
							if (!memberGradeUpdateSuccess) {
								out.println("<script>");
								out.println("alert('등급 업데이트에 실패하였습니다.');");
								out.println("window.opener='Self';");
								out.println("window.open('','_parent','');");
								out.println("window.close();");
								out.println("</script>");
							} else {
								updateGrade = "A-";
							}
						} else if (grade.equalsIgnoreCase("C") && allDonationMoney >= 1000000) {
							MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
							boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeBUpdate(member_id, member_category);
							
							if (!memberGradeUpdateSuccess) {
								out.println("<script>");
								out.println("alert('등급 업데이트에 실패하였습니다.');");
								out.println("window.opener='Self';");
								out.println("window.open('','_parent','');");
								out.println("window.close();");
								out.println("</script>");
							} else {
								updateGrade = "B";
							}
						}
					}
				}
			}
			if (updateGrade.equalsIgnoreCase("A")) {
				forward = new ActionForward("regularlyPayMentApproveSuccessMemberGradeAUpdate.page", false);
			} else if (updateGrade.equalsIgnoreCase("A-")) {
				forward = new ActionForward("regularlyPayMentApproveSuccessMemberGradeAMinusUpdate.page", false);
			} else if (updateGrade.equalsIgnoreCase("B")) {
				forward = new ActionForward("regularlyPayMentApproveSuccessMemberGradeBUpdate.page", false);
			} else {
				forward = new ActionForward("regularlyPayMentApproveSuccess.page", false);
			}
		}
		return forward;
	}

}
