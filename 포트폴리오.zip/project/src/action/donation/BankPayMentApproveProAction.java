package action.donation;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.campaign.CampaignUpdateService;
import svc.donation.DonationService;
import svc.donation.MemberDonationMoneyService;
import svc.donation.MemberGradeUpdateService;
import svc.donation.MyInfoService;
import svc.login.DeleteMemberChkService;
import vo.ActionForward;

public class BankPayMentApproveProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		int campaign_no = Integer.parseInt(request.getParameter("campaign_no"));
		int donation_no = Integer.parseInt(request.getParameter("donation_no"));
		String member_id = request.getParameter("member_id");
		long donation_money1 = 0;
		String updateGrade = "";
		
		DeleteMemberChkService memberChkService = new DeleteMemberChkService();
		String member_category = memberChkService.isDeleteMemberCategory(member_id);
		
		MemberDonationMoneyService memberDonationMoneyService = new MemberDonationMoneyService();
		if (member_category.equalsIgnoreCase("normal")) {
			donation_money1 = memberDonationMoneyService.getNormalMemberDonationMoney(donation_no, member_id);
		} else if (member_category.equalsIgnoreCase("comgrp")) {
			donation_money1 = memberDonationMoneyService.getComgrpMemberDonationMoney(donation_no, member_id);
		}
		
		DonationService donationService = new DonationService();
		boolean donationApproveSuccess = false;
		if (member_category.equalsIgnoreCase("normal")) {
			donationApproveSuccess = donationService.donationApproveBankNormalMember(donation_no, member_id);
		} else if (member_category.equalsIgnoreCase("comgrp")) {
			donationApproveSuccess = donationService.donationApproveBankComgrpMember(donation_no, member_id);
		}
		if (!donationApproveSuccess) {
			out.println("<script>");
			out.println("alert('계좌결제 승인에 실패하였습니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			CampaignUpdateService campaignUpdateService = new CampaignUpdateService();
			boolean campaignUpdateSuccess = campaignUpdateService.campaignUpdateAllFundRaised(campaign_no, donation_money1);
			
			if (!campaignUpdateSuccess) {
				out.println("<script>");
				out.println("alert('계좌결제 승인 후 후원금 업데이트에 실패하였습니다.');");
				out.println("window.opener='Self';");
				out.println("window.open('','_parent','');");
				out.println("window.close();");
				out.println("</script>");
			} else {
				MyInfoService myInfoService = new MyInfoService();
				int allDonationMoney = myInfoService.getAllDonationMoney(member_id, member_category);
				String grade = myInfoService.getGrade(member_id, member_category);
				
				if ((grade.equalsIgnoreCase("A-") && allDonationMoney >= 100000000) || (grade.equalsIgnoreCase("B") && allDonationMoney >= 100000000) || (grade.equalsIgnoreCase("C") && allDonationMoney >= 100000000)) {
					MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
					boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeAUpdate(member_id, member_category);
					
					if (!memberGradeUpdateSuccess) {
						out.println("<script>");
						out.println("alert('등급 업데이트에 실패하였습니다.');");
						out.println("window.opener='Self';");
						out.println("window.open('','_parent','');");
						out.println("window.close();");
						out.println("</script>");
					} else {
						updateGrade = "A";
					}
				}  else if ((grade.equalsIgnoreCase("B") && allDonationMoney >= 10000000) || (grade.equalsIgnoreCase("C") && allDonationMoney >= 10000000)) {
					MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
					boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeAMinusUpdate(member_id, member_category);
					
					if (!memberGradeUpdateSuccess) {
						out.println("<script>");
						out.println("alert('등급 업데이트에 실패하였습니다.');");
						out.println("window.opener='Self';");
						out.println("window.open('','_parent','');");
						out.println("window.close();");
						out.println("</script>");
					} else {
						updateGrade = "A-";
					}
				} else if (grade.equalsIgnoreCase("C") && allDonationMoney >= 1000000) {
					MemberGradeUpdateService memberGradeUpdateService = new MemberGradeUpdateService();
					boolean memberGradeUpdateSuccess = memberGradeUpdateService.gradeBUpdate(member_id, member_category);
					
					if (!memberGradeUpdateSuccess) {
						out.println("<script>");
						out.println("alert('등급 업데이트에 실패하였습니다.');");
						out.println("window.opener='Self';");
						out.println("window.open('','_parent','');");
						out.println("window.close();");
						out.println("</script>");
					} else {
						updateGrade = "B";
					}
				}
			}
			if (updateGrade.equalsIgnoreCase("A")) {
				forward = new ActionForward("bankPayMentApproveSuccessMemberGradeAUpdate.page", false);
			} else if (updateGrade.equalsIgnoreCase("A-")) {
				forward = new ActionForward("bankPayMentApproveSuccessMemberGradeAMinusUpdate.page", false);
			} else if (updateGrade.equalsIgnoreCase("B")) {
				forward = new ActionForward("bankPayMentApproveSuccessMemberGradeBUpdate.page", false);
			} else {
				forward = new ActionForward("bankPayMentApproveSuccess.page", false);
			}
		}
		return forward;
	}

}
