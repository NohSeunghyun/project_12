package action.donation;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.admin.AdminGradeChkService;
import vo.ActionForward;

public class RegularlyPayMentApproveAdminGradeChkProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		HttpSession session = request.getSession();
		String admin_id = (String)session.getAttribute("id");
		
		String campaign_no = request.getParameter("campaign_no");
		String donation_no = request.getParameter("donation_no");
		String member_id = request.getParameter("member_id");
		String pay_type = request.getParameter("pay_type");
		String pay_date = request.getParameter("pay_date");
		
		AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
		String admin_grade = adminGradeChkService.isAdminGrade(admin_id);
		
		if (!admin_grade.equalsIgnoreCase("A")) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			
			out.println("<script>");
			out.println("alert('결제할 권한이 없습니다.\\nA등급만 정기결제 가능합니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			request.setAttribute("campaign_no", campaign_no);
			request.setAttribute("donation_no", donation_no);
			request.setAttribute("member_id", member_id);
			request.setAttribute("pay_type", pay_type);
			request.setAttribute("pay_date", pay_date);
			
			forward = new ActionForward("regularlyPaymentApproveAlert.page", false);
		}
		return forward;
	}

}
