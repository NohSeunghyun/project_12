package action.donation;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.campaign.CampaignListService;
import svc.donation.DonationBankInfoService;
import svc.donation.DonationCardInfoService;
import svc.donation.DonationHistoryService;
import svc.login.DeleteMemberChkService;
import vo.ActionForward;
import vo.campaign.CampaignBean;
import vo.donation.DonationBankBean;
import vo.donation.DonationBean;
import vo.donation.DonationCardBean;

public class MemberRegularlyInfoProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		CampaignListService campaignListService = new CampaignListService();
		ArrayList<CampaignBean> campaignList = campaignListService.getCampaign();
		
		request.setAttribute("campaignList", campaignList);
		
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		
		DeleteMemberChkService deleteMemberChkService = new DeleteMemberChkService();
		String category = deleteMemberChkService.isDeleteMemberCategory(id);
		
		DonationHistoryService donationHistoryService = new DonationHistoryService();
		if (category == "normal") {
			ArrayList<DonationBean> normalMemberDonationHistory = donationHistoryService.normalMemberDonationHistory(id);
			
			DonationCardInfoService donationCardInfoService = new DonationCardInfoService();
			ArrayList<DonationCardBean> normalMemberDonationCardInfo = donationCardInfoService.getNormalMemberDonationCardInfo();
			
			DonationBankInfoService donationBankInfoService = new DonationBankInfoService();
			ArrayList<DonationBankBean> normalMemberDonationBankInfo = donationBankInfoService.getNormalMemberDonationBankInfo();
			
			request.setAttribute("memberDonationBankInfo", normalMemberDonationBankInfo);
			request.setAttribute("memberDonationCardInfo", normalMemberDonationCardInfo);
			request.setAttribute("memberDonationHistory", normalMemberDonationHistory);
			
			forward = new ActionForward("memberRegularlyInfoForm.page", false);
		} else if (category == "comgrp") {
			ArrayList<DonationBean> comgrpMemberDonationHistory = donationHistoryService.comgrpMemberDonationHistory(id);
			
			DonationCardInfoService donationCardInfoService = new DonationCardInfoService();
			ArrayList<DonationCardBean> comgrpMemberDonationCardInfo = donationCardInfoService.getComgrpMemberDonationCardInfo();
			
			DonationBankInfoService donationBankInfoService = new DonationBankInfoService();
			ArrayList<DonationBankBean> comgrpMemberDonationBankInfo = donationBankInfoService.getComgrpMemberDonationBankInfo();
			
			request.setAttribute("memberDonationBankInfo", comgrpMemberDonationBankInfo);
			request.setAttribute("memberDonationCardInfo", comgrpMemberDonationCardInfo);
			request.setAttribute("memberDonationHistory", comgrpMemberDonationHistory);
			
			forward = new ActionForward("memberRegularlyInfoForm.page", false);
		}
		return forward;
	}

}
