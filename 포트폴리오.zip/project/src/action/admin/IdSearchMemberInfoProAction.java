package action.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.admin.AdminMemberInformationService;
import svc.admin.MemberInformationService;
import vo.ActionForward;
import vo.login.AdminMemberBean;
import vo.login.CompanyGroupMemberBean;
import vo.login.NormalMemberBean;

public class IdSearchMemberInfoProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		String id = request.getParameter("id");
		String category = "";
		
		MemberInformationService memberInformationService = new MemberInformationService();
		NormalMemberBean normalMemberInfo = memberInformationService.adminNormalMemberInfo(id);
		
		if (normalMemberInfo != null) {
			category = "normal";
			request.setAttribute("memberInfo", normalMemberInfo);
			request.setAttribute("category", category);
			forward = new ActionForward("searchIdMemberInfo.page", false);
		} else {
			CompanyGroupMemberBean comgrpMemberInfo = memberInformationService.adminComgrpMemberInfo(id);
			
			if (comgrpMemberInfo != null) {
				category = "comgrp";
				request.setAttribute("memberInfo", comgrpMemberInfo);
				request.setAttribute("category", category);
				forward = new ActionForward("searchIdMemberInfo.page", false);
			} else {
				AdminMemberInformationService adminMemberInformationService = new AdminMemberInformationService();
				AdminMemberBean adminMemberInfo = adminMemberInformationService.adminMemberInfo(id);
				
				if (adminMemberInfo != null) {
					category = "admin";
					request.setAttribute("memberInfo", adminMemberInfo);
					request.setAttribute("category", category);
					forward = new ActionForward("searchIdMemberInfo.page", false);
				} else {
					response.setContentType("text/html;charset=utf-8");
					PrintWriter out = response.getWriter();
					
					out.println("<script>");
					out.println("alert('검색결과가 없습니다.\\n검색하실 아이디를 확인해 주세요.');");
					out.println("history.back();");
					out.println("</script>");
				}
			}
		}
		return forward;
	}

}
